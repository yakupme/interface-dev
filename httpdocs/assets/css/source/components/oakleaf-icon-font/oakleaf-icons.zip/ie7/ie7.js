/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'oakleaf-icons\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-brackets': '&#xe600;',
		'icon-contracts_placed': '&#xe601;',
		'icon-conversion': '&#xe602;',
		'icon-csr_charity': '&#xe603;',
		'icon-down_arrow': '&#xe604;',
		'icon-email': '&#xe605;',
		'icon-executive': '&#xe606;',
		'icon-facebook': '&#xe607;',
		'icon-graduate': '&#xe608;',
		'icon-growth': '&#xe609;',
		'icon-headcount': '&#xe60a;',
		'icon-hr_jobs': '&#xe60b;',
		'icon-human_capital_services': '&#xe60c;',
		'icon-international': '&#xe60d;',
		'icon-joiners': '&#xe60e;',
		'icon-left_arrow': '&#xe60f;',
		'icon-left_chevron': '&#xe610;',
		'icon-linkedin': '&#xe611;',
		'icon-marketing': '&#xe612;',
		'icon-pagination_outline': '&#xe613;',
		'icon-pagination_solid': '&#xe614;',
		'icon-part_time': '&#xe615;',
		'icon-payroll': '&#xe616;',
		'icon-pensions': '&#xe617;',
		'icon-percentage': '&#xe618;',
		'icon-phone': '&#xe619;',
		'icon-quote_bottom': '&#xe61a;',
		'icon-quote_top': '&#xe61b;',
		'icon-radio_button_selected': '&#xe61c;',
		'icon-radio_button': '&#xe61d;',
		'icon-research': '&#xe61e;',
		'icon-revenue': '&#xe61f;',
		'icon-reward_jobs': '&#xe620;',
		'icon-right_arrow': '&#xe621;',
		'icon-right_chevron': '&#xe622;',
		'icon-search': '&#xe623;',
		'icon-sector_split': '&#xe624;',
		'icon-turnover': '&#xe625;',
		'icon-twitter': '&#xe626;',
		'icon-up_arrow': '&#xe627;',
		'icon-years_experience': '&#xe628;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
